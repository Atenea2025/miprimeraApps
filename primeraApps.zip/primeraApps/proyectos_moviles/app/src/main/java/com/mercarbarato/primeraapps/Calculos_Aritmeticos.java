package com.mercarbarato.primeraapps;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class Calculos_Aritmeticos extends AppCompatActivity {

    private TextView tv1;
    private EditText et1,et2;
    private TextView tv3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculos_aritmeticos);
        tv1 = (TextView) findViewById(R.id.tv1);
        String dato = getIntent().getStringExtra("dato");
        tv1.setText("Hola: " + dato);

        et1 = (EditText) findViewById(R.id.et1);
        et2 = (EditText) findViewById(R.id.et2);
        tv3 = (TextView) findViewById(R.id.tv3);


    }

    //Método para el botón regresar
    public void Regresar(View view){
        Intent anterior = new Intent(this,MainActivity.class);
        startActivity(anterior);
    }

    //Métoo sumar
    public void Sumar(View view){
        String valor1 = et1.getText().toString();
        String valor2 = et2.getText().toString();
        double nro1 = Double.parseDouble(valor1);
        double nro2 = Double.parseDouble(valor2);
        double suma = nro1 + nro2;
        String resu = String.valueOf(suma);
        tv3.setText(resu);

    }


}