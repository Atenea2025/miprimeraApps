package com.mercarbarato.primeraapps;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelStoreOwner;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;


public class MainActivity extends AppCompatActivity {

    private EditText edtNombre1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edtNombre1 = (EditText) findViewById(R.id.edtNombre1);
    }

    //Método para el botón siguiente
    public void Continuar(View view){
        Intent siguiente = new Intent(this,Calculos_Aritmeticos.class);
        siguiente.putExtra("dato",edtNombre1.getText().toString());
        startActivity(siguiente);
    }



}